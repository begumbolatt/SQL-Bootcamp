--Bu veritaban� bir film veritaban�d�r. ��eirisinde filmler, akt�rler, y�netmenler, kullan�c�lar, ve izlenme ge�mi�i bilgilerinin i�erildi�i bir �ok tablo da bulundurur.

--#### CREATE DATABASE ####

CREATE DATABASE MoviesDatabase
USE MoviesDatabase

--#### CREATE TABLES ####

--Genres tablosu: Film t�rleri i�in.
CREATE TABLE Genres(
	GenreID INT PRIMARY KEY IDENTITY(1,1),
	GenreName NVARCHAR(255),
);

--Directors tablosu: Y�netmenleri i�eren tablo.
CREATE TABLE Directors(
	DirectorID INT PRIMARY KEY IDENTITY(1,1),
	DirectorName NVARCHAR(255),
);

--Movies tablosu: Filmlerin oldu�u tablo. Gneres ve Directors tablosu ile ba�lant�l�.
CREATE TABLE Movies(
	MovieID INT PRIMARY KEY IDENTITY(1,1),
	Title NVARCHAR(255),
	ReleaseYear INT, 
	DirectorID INT FOREIGN KEY REFERENCES Directors(DirectorID),
	GenreID INT FOREIGN KEY REFERENCES Genres(GenreID),
	Rating DECIMAL(3,1),
);

--Actors tablosu: Akt�rlerin bilgilerini i�eren tablo
CREATE TABLE Actors(
	ActorID INT PRIMARY KEY IDENTITY(1,1),
	ActorName NVARCHAR(255),
);

--Roles tablosu
CREATE TABLE Roles (
    RoleID INT PRIMARY KEY IDENTITY(1,1),
    RoleName NVARCHAR(255)
);

--Actors-Movies  ile ili�kili tablo
CREATE TABLE ActorMovie(
	ActorMovieID INT PRIMARY KEY IDENTITY(1,1),
	ActorID INT FOREIGN KEY REFERENCES Actors(ActorID),
	MovieID INT FOREIGN KEY REFERENCES Movies(MovieID),
	RoleID INT FOREIGN KEY REFERENCES Roles(RoleID),
);

--Users tablosu: Kullan�c� bilgilerinin saklayaca��m�z tablo
CREATE TABLE Users(
	UserID INT PRIMARY KEY IDENTITY(1,1),
	UserName NVARCHAR(255) NOT NULL UNIQUE,
	Email NVARCHAR(255) NOT NULL UNIQUE,
);

--�zlenme ge�mi�i tablosu
CREATE TABLE WatchHistory(
	WatchID INT PRIMARY KEY IDENTITY(1,1),
	UserID INT FOREIGN KEY REFERENCES Users(UserID),
	MovieID INT FOREIGN KEY REFERENCES Movies(MovieID),
	WatchDate DATE,
);

--#### INSERT DATA ####

--Genres:
INSERT INTO Genres (GenreName) VALUES
('Action'),
('Drama'),
('Comedy'),
('Sci-Fi'),
('Thriller'),
('Romance'),
('Horror'),
('Mystery'),
('Documentary'),
('Adventure'),
('Animation');

--Directors
INSERT INTO Directors (DirectorName)
VALUES
('Steven Spielberg'),
('Martin Scorsese'),
('Quentin Tarantino'),
('Christopher Nolan'),
('Alfred Hitchcock'),
('Francis Ford Coppola'),
('Stanley Kubrick'),
('James Cameron'),
('George Lucas'),
('Tim Burton'),
('David Lynch'),
('Clint Eastwood'),
('Coen Brothers'),
('Ridley Scott'),
('Ang Lee'),
('Woody Allen'),
('Peter Jackson'),
('Darren Aronofsky'),
('David Cronenberg'),
('Akira Kurosawa'),
('Federico Fellini'),
('Pedro Almod�var'),
('Charlie Chaplin'),
('Orson Welles'),
('Sergio Leone'),
('Wong Kar-wai'),
('Quentin Tarantino'),
('Steven Spielberg'),
('Martin Scorsese'),
('Christopher Nolan'),
('Alfred Hitchcock'),
('Francis Ford Coppola'),
('Stanley Kubrick'),
('James Cameron'),
('George Lucas'),
('Tim Burton'),
('David Lynch'),
('Clint Eastwood'),
('Coen Brothers'),
('Ridley Scott'),
('Ang Lee'),
('Woody Allen'),
('Peter Jackson'),
('Darren Aronofsky'),
('David Cronenberg'),
('Akira Kurosawa'),
('Federico Fellini'),
('Pedro Almod�var'),
('Charlie Chaplin'),
('Orson Welles'),
('Sergio Leone'),
('Wong Kar-wai');

--Actors tablosunun verileri
INSERT INTO Actors (ActorName)
VALUES
('Tom Hardy'),
('Jennifer Aniston'),
('Chris Evans'),
('Emma Stone'),
('Ryan Reynolds'),
('Angelina Jolie'),
('Chadwick Boseman'),
('Anne Hathaway'),
('Daniel Radcliffe'),
('Margot Robbie'),
('Idris Elba'),
('Natalie Dormer'),
('Eddie Redmayne'),
('Charlize Theron'),
('Bradley Cooper'),
('Gemma Chan'),
('Keanu Reeves'),
('Scarlett Johansson'),
('Ryan Gosling'),
('Alicia Vikander'),
('Chris Pratt'),
('Brie Larson'),
('Jared Leto'),
('Rachel McAdams'),
('Henry Cavill'),
('Elizabeth Olsen'),
('Jake Gyllenhaal'),
('Keira Knightley'),
('Michael B. Jordan'),
('Olivia Wilde'),
('Matthew McConaughey'),
('Penelope Cruz'),
('Tom Holland'),
('Zoe Kravitz'),
('Tessa Thompson'),
('Chris Hemsworth'),
('Zac Efron'),
('Daisy Ridley'),
('Jason Momoa'),
('Sophie Turner'),
('Robert Pattinson'),
('Cate Blanchett'),
('Shia LaBeouf'),
('Emily Blunt'),
('Jodie Comer'),
('Joaquin Phoenix'),
('Nicole Kidman'),
('Oscar Isaac'),
('Saoirse Ronan'),
('Timoth�e Chalamet'),
('Viola Davis'),
('Hugh Jackman'),
('Gal Gadot'),
('Mark Ruffalo'),
('Emilia Clarke'),
('Kit Harington'),
('Laura Dern'),
('Jason Statham'),
('Mila Kunis'),
('Denzel Washington'),
('Megan Fox'),
('George Clooney'),
('Meryl Streep'),
('Leonardo DiCaprio'),
('Natalie Portman'),
('Robert De Niro'),
('Julia Roberts'),
('Charlize Theron'),
('Johnny Depp'),
('Matthew McConaughey'),
('Sandra Bullock'),
('George Clooney'),
('Christian Bale'),
('Emma Watson'),
('Mila Kunis'),
('Chris Hemsworth'),
('Amy Adams'),
('Michael Fassbender'),
('Reese Witherspoon'),
('Natalie Dormer'),
('Javier Bardem'),
('Gwyneth Paltrow'),
('Keanu Reeves'),
('Nicole Kidman'),
('Idris Elba'),
('Cameron Diaz'),
('Eddie Redmayne'),
('Zendaya'),
('Matt Damon'),
('Gal Gadot'),
('Cillian Murphy'),
('Octavia Spencer'),
('Jude Law'),
('Zoe Saldana'),
('Tilda Swinton'),
('John Boyega'),
('Tom Cruise'),
('Kate Winslet'),
('Ben Affleck'),
('Halle Berry');

--Roller tablosunun verileri
INSERT INTO Roles (RoleName)
VALUES
('Main Character'),
('Supporting Character'),
('Lead Role'),
('Co-Star'),
('Guest Actor');

--Filmler tablosuna eklenen rastgele 50.000 tane film verisi
DECLARE @counter INT = 1
WHILE @counter <= 50000
BEGIN
	DECLARE @randomDirectorID INT = ROUND(RAND() * 51 + 1, 0); --1 ile 52 aras�nda rastgele D�rectorID atar
	DECLARE @randomGenreID INT = ROUND(RAND() * 10 + 1, 0); --1 ile 11 aras�nda rastgele GenreID atar
	DECLARE @randomReleaseYear INT = ROUND(RAND() * (2024 - 1990 +1) + 1989, 0); --2024 - 1990 y�llar� aras�nda random atama yapar
	DECLARE @randomRating DECIMAL(3,1) = ROUND(RAND() * 5, 1); --Max 5.0 olacak �ekilde rastgele oylama puan� atar
	DECLARE @title NVARCHAR(255) = CONCAT('Movie', @counter); --Film ad� 

	INSERT INTO Movies(Title, ReleaseYear, DirectorID, GenreID, Rating) 
	VALUES(@title, @randomReleaseYear, @randomDirectorID, @randomGenreID, @randomRating)

	SET @counter = @counter + 1;
END;

GO

--Kullan�c�lar tablosu i�in 50.000 tane farkl� kullan�c� olu�turdu
DECLARE @counter INT = 1
WHILE @counter <= 50000
BEGIN
    DECLARE @randomUserName NVARCHAR(255) = CONCAT('User', @counter);  --Kullan�c�ya random Username �retir
    DECLARE @randomEmail NVARCHAR(255) = CONCAT('info', @counter, '@mail.com'); -- Kullan�c�ya rastgele ve unique mail adresi olu�turur
    

    INSERT INTO Users (UserName, Email)
    VALUES (@randomUserName, @randomEmail);

    SET @counter = @counter + 1;
END;

GO

--Actor-Movie tablosuna 50.000 rastgele veri ekleme
DECLARE @counter INT = 1;

WHILE @counter <= 50000
BEGIN
    DECLARE @randomActorID INT = ROUND(RAND() * 99 + 1, 0);  -- 1-100 aras� rastgele oyuncu ID'si
    DECLARE @randomMovieID INT = ROUND(RAND() * 49999 + 1, 0); -- 1-50000 aras� rastgele film ID'si
    DECLARE @randomRoleID INT = ROUND(RAND() * 4 + 1, 0); -- 1-5 aras� rastgele rol ID'si

    INSERT INTO ActorMovie (ActorID, MovieID, RoleID)
    VALUES (@randomActorID, @randomMovieID, @randomRoleID);

    SET @counter = @counter + 1;
END;

GO

--WatchHistory tablosuna random 40.000 veri eklenmesi
DECLARE @counter INT = 1;

WHILE @counter <= 40000
BEGIN
    DECLARE @randomUser INT = ROUND(RAND() * 49999 + 1, 0)
    DECLARE @randomMovie NVARCHAR(255) = ROUND(RAND() * 49999 + 1, 0)
    DECLARE @randomDate DATETIME = DATEADD(DAY, ROUND(RAND() * DATEDIFF(DAY, '2000-01-01', GETDATE()),0), '2000-01-01')

    INSERT INTO WatchHistory (UserID, MovieID, WatchDate)
    VALUES (@randomUser, @randomMovie, @randomDate);

    SET @counter = @counter + 1;
END

GO

--Q1.En �ok filmde rol alm�� akt�r�n bilgileri
SELECT TOP 1
A.ActorID, A.ActorName, COUNT(ActorMovie.ActorMovieID) AS MovieCount
FROM Actors A
JOIN ActorMovie ON A.ActorID = ActorMovie.ActorID
GROUP BY A.ActorID, A.ActorName
ORDER BY MovieCount DESC;

--Q2.En �ok hangi y�netmen hangi oyuncu ile �al��m��t�r
SELECT TOP 1
D.DirectorName, A.ActorName, COUNT(*) AS WorkCount
FROM Directors D
JOIN Movies M ON D.DirectorID = M.DirectorID
JOIN ActorMovie ON M.MovieID = ActorMovie.MovieID
JOIN Actors A ON ActorMovie.ActorID = A.ActorID
GROUP BY D.DirectorID, D.DirectorName, A.ActorID, A.ActorName
ORDER BY WorkCount DESC

--Q3.En �ok film izleyen kullan�cn�n bilgileri
SELECT TOP 1
U.UserID, U.UserName, U.Email, COUNT(*) AS TotalWatchCount
FROM Users U
JOIN WatchHistory WH ON U.UserID = WH.UserID
GROUP BY U.UserID, U.UserName, U.Email
ORDER BY TotalWatchCount DESC

--Q4.Filmlerin Ratingi 3.5 �zerinde ise 'Y�ksek Puanl�' de�ilse 'D���k Puanl�' yazmas�
DECLARE @MinRate FLOAT
SET @MinRate = 3.5
SELECT
M.MovieID, M.Title, M.ReleaseYear, 
D.DirectorName AS Director, 
G.GenreName AS Genre, 
M.Rating,
	CASE 
		WHEN M.Rating >= @MinRate THEN 'Y�ksek Puanl�'
		ELSE 'D���k Puanl�'
	END AS Result
FROM Movies M
JOIN Directors D ON M.DirectorID = D.DirectorID
JOIN Genres G ON M.GenreID = G.GenreID

--Q5.En son izlenen film ve izleyen kullan�c�n�n bilgilerini getiren sorgu
SELECT
U.UserName,
M.Title AS MovieName,
D.DirectorName AS Director,
G.GenreName AS Genre,
WH.WatchDate AS Date
FROM WatchHistory WH
JOIN Users U ON WH.UserID = U.UserID
JOIN Movies M ON WH.MovieID = M.MovieID
JOIN Directors D ON M.DirectorID = D.DirectorID
JOIN Genres G ON M.GenreID = G.GenreID
WHERE WH.WatchDate = (SELECT MAX(WatchDate) FROM WatchHistory)

--Users tablosuna TotalWatchCountlar� i�in bir s�tun eklendi
ALTER TABLE Users
ADD TotalWatchCount INT DEFAULT 0;

--Her bir kullan�c�n�n izledi�i watch countlar i�in TotalWatchCount s�tunlar� g�ncenlendi
UPDATE Users
SET TotalWatchCount = (
	SELECT COUNT(*)
	FROM WatchHistory
	WHERE UserID = Users.UserID
)

--Movies tablosuna WatchCount ekledik. Her bir filmin ka� izlendi�ini g�steren s�tun
ALTER TABLE Movies
ADD WatchCount INT DEFAULT 0;

--Movies tablosuna ekledi�imiz WatchCountlar�n say�lar�n� MovieIDlerine g�re g�ncelledik
UPDATE Movies
SET WatchCount = WatchHistoryCounts.WatchCount
FROM Movies
INNER JOIN (
    SELECT 
        Movies.MovieID,
        COUNT(WatchHistory.MovieID) AS WatchCount
    FROM 
        Movies
    LEFT JOIN 
        WatchHistory ON Movies.MovieID = WatchHistory.MovieID
    GROUP BY 
        Movies.MovieID
) AS WatchHistoryCounts ON Movies.MovieID = WatchHistoryCounts.MovieID;

GO

--Belirli bir kullan�c�n�n belirli bir filmi izlemesi durumunda WatchHistory tablosuna yeni bir giri� ekleyen bir stored procedure
CREATE PROCEDURE WatchMovie
	@UserID INT,
	@MovieID INT,
	@WatchDate DATE
AS
BEGIN
	--Kullan�c�n�n belirli bir filmi izleme ge�mi�ine yeni bir giri� ekler
	INSERT INTO WatchHistory(UserID, MovieID, WatchDate)
	VALUES (@UserID, @MovieID, @WatchDate);

	--Kullan�c�n�n toplam izleme say�s�n� g�nceller
    UPDATE Users
    SET TotalWatchCount = TotalWatchCount + 1
    WHERE UserID = @UserID;

	  --Filmin izlenme say�s�n� g�nceller
    UPDATE Movies
    SET WatchCount = WatchCount + 1
    WHERE MovieID = @MovieID;
    
END;

SELECT * FROM Users WHERE UserID = 7 --TotalWatchCount = 3
SELECT * FROM Movies WHERE MovieID = 1234 --WatchCount = 2

--Procedure �al��t�ral�m
EXECUTE WatchMovie @UserID = 7, @MovieID = 1234, @WatchDate = '2024-02-10';

SELECT * FROM Users WHERE UserID = 7 --TotalWatchCount = 4
SELECT * FROM Movies WHERE MovieID = 1234 --WacthCount = 3

GO

SELECT * FROM WatchHistory WHERE MovieID = 475; --3 adet izleme ge�mi�i bulunuyor

GO

--Silinen filmle ili�kilendirilmi� t�m izleme ge�mi�ini WatchHistory tablosundan otomatik olarak kald�ran trigger i�lemi
CREATE TRIGGER UpdateWatchHistoryOnMovieDelete
ON Movies
AFTER DELETE
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @DeletedMovieID INT;
    SELECT @DeletedMovieID = MovieID FROM deleted;

    -- �lgili filmi izleyen t�m kullan�c�lar�n izleme ge�mi�ini sil
    DELETE FROM WatchHistory WHERE MovieID = @DeletedMovieID;
END;


DELETE FROM Movies WHERE MovieID = 1754;

SELECT * FROM WatchHistory WHERE MovieID = 1754; --0 adet izleme ge�mi�i bulunuyor

GO

--Her kullan�c�n�n izledi�i filmlerin filmlerin detaylar� ve izleme tarihlerini i�eren view sorgusu
CREATE VIEW UsersWatchHistory AS
SELECT 
	U.UserName,
	M.Title AS MovieName,
	M.ReleaseYear,
	D.DirectorName AS Director,
	G.GenreName AS Genre,
	WH.WatchDate
FROM
	WatchHistory WH
	JOIN Users U ON WH.UserID = U.UserID
	JOIN Movies M ON WH.MovieID = M.MovieID
	JOIN Directors D ON M.DirectorID = D.DirectorID
	JOIN Genres G ON M.GenreID = G.GenreID

--Viewi �al��t�rma
SELECT * FROM UsersWatchHistory